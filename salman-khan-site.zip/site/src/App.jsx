import Hero from './sections/Hero'
import { Pillars, Principles, AIWork, Experience, Stack, Marquee, Contact } from './sections/Sections'
import { profile } from './data'

function Nav() {
  return (
    <nav className="nav">
      <div className="wrap nav-in">
        <a className="brand" href="#top"><span className="dot" />SALMAN KHAN</a>
        <div className="nav-links">
          <a href="#work">What I do</a>
          <a href="#how">How I work</a>
          <a href="#ai">Applied AI</a>
          <a href="#experience">Experience</a>
          <a href="#stack">Stack</a>
        </div>
        <a className="nav-cta" href="#contact">Get in touch</a>
      </div>
    </nav>
  )
}

export default function App() {
  return (
    <div id="top">
      <Nav />
      <Hero />
      <Marquee />
      <Pillars />
      <Principles />
      <AIWork />
      <Experience />
      <Stack />
      <Contact />
      <footer className="wrap footer">
        <span>&copy; {new Date().getFullYear()} {profile.name} &middot; {profile.location}</span>
        <span>Built with React &amp; Framer Motion</span>
      </footer>
    </div>
  )
}
