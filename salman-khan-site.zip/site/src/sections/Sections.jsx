import { useState } from 'react'
import { motion } from 'framer-motion'
import { pillars, principles, aiWork, experience, stack, profile, education } from '../data'
import { fadeUp, stagger, viewport } from '../motion'

function Head({ eyebrow, title, text }) {
  return (
    <motion.div className="section-head" variants={stagger} initial="hidden" whileInView="show" viewport={viewport}>
      <motion.span className="eyebrow" variants={fadeUp}>{eyebrow}</motion.span>
      <motion.h2 variants={fadeUp}>{title}</motion.h2>
      {text && <motion.p variants={fadeUp}>{text}</motion.p>}
    </motion.div>
  )
}

export function Pillars() {
  return (
    <section className="section" id="work">
      <div className="wrap">
        <Head
          eyebrow="What I do"
          title="Three hats, one accountable owner."
          text="Product direction, team leadership and hands-on engineering from the same person, so nothing gets lost between the spec, the squad and the code."
        />
        <motion.div className="pillars" variants={stagger} initial="hidden" whileInView="show" viewport={viewport}>
          {pillars.map((p, i) => (
            <motion.article
              className="pillar"
              key={p.key}
              variants={fadeUp}
              whileHover={{ y: -4 }}
              transition={{ type: 'spring', stiffness: 300, damping: 24 }}
            >
              <span className="idx">{String(i + 1).padStart(2, '0')}</span>
              <h3>{p.title}</h3>
              <p className="lead">{p.lead}</p>
              <ul>{p.points.map((pt) => <li key={pt}>{pt}</li>)}</ul>
            </motion.article>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

const icons = [
  // engineered
  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M14.5 4.5l5 5-10 10h-5v-5z" /><path d="M12 7l5 5" /></svg>,
  // scalable
  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2" /></svg>,
  // reliable
  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M3 12h4l2-5 4 10 2-5h6" /></svg>,
  // secure
  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6z" /><path d="M9 12l2 2 4-4" /></svg>,
  // end to end
  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="5" cy="12" r="2" /><circle cx="19" cy="12" r="2" /><path d="M7 12h10" /></svg>,
  // communicator
  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M4 5h16v10H9l-5 4z" /></svg>,
]

export function Principles() {
  return (
    <section className="section" id="how">
      <div className="wrap">
        <Head
          eyebrow="How I work"
          title="Built to run, not just to demo."
          text="The standards every system I own has to meet before it is called done."
        />
        <motion.div className="principles" variants={stagger} initial="hidden" whileInView="show" viewport={viewport}>
          {principles.map((p, i) => (
            <motion.div className="principle" key={p.title} variants={fadeUp}>
              <span className="mark">{icons[i]}</span>
              <h3>{p.title}</h3>
              <p>{p.text}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

export function AIWork() {
  return (
    <section className="section" id="ai">
      <div className="wrap">
        <Head
          eyebrow="Applied AI"
          title="LLM features in production, not in slides."
          text="RAG, streaming inference and tool-calling agents shipped into live operational systems, with evals, guardrails and cost/latency trade-offs handled up front."
        />
        <motion.div className="ai-grid" variants={stagger} initial="hidden" whileInView="show" viewport={viewport}>
          {aiWork.map((a) => (
            <motion.article className="ai-card" key={a.title} variants={fadeUp} whileHover={{ y: -3 }} transition={{ type: 'spring', stiffness: 300, damping: 24 }}>
              <span className="where">{a.where}</span>
              <h3>{a.title}</h3>
              <p>{a.text}</p>
              <div className="chips">{a.stack.map((s) => <span className="chip" key={s}>{s}</span>)}</div>
            </motion.article>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

export function Experience() {
  return (
    <section className="section" id="experience">
      <div className="wrap">
        <Head
          eyebrow="Experience"
          title={`${new Date().getFullYear() - profile.since}+ years, since 2013.`}
          text="Aviation, real-money iGaming, e-commerce and enterprise software. Most recent first."
        />
        <div className="timeline">
          {experience.map((j) => (
            <motion.div
              className="job"
              key={j.company + j.period}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.25 }}
              transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
            >
              <div className="when">
                <b>{j.period}</b>
                <span>{j.place}</span>
              </div>
              <div className="what">
                <h3>{j.company} <span>{j.role}</span></h3>
                <span className="domain">{j.domain}</span>
                <ul>{j.bullets.map((b) => <li key={b}>{b}</li>)}</ul>
              </div>
            </motion.div>
          ))}
        </div>
        <p style={{ marginTop: 28, color: 'var(--muted)', fontSize: 14 }}>{education}</p>
      </div>
    </section>
  )
}

export function Stack() {
  return (
    <section className="section" id="stack">
      <div className="wrap">
        <Head eyebrow="Stack" title="Tools I ship with." />
        <motion.div className="stack" variants={stagger} initial="hidden" whileInView="show" viewport={viewport}>
          {stack.map((g) => (
            <motion.div className="stack-row" key={g.group} variants={fadeUp}>
              <h3>{g.group}</h3>
              <div className="chips">{g.items.map((s) => <span className="chip" key={s}>{s}</span>)}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

const marqueeItems = ['Node.js', 'TypeScript', 'React', 'Next.js', 'PostgreSQL', 'Kafka', 'Kubernetes', 'AWS', 'Azure', 'OpenAI', 'LangChain.js', 'RAG', 'SAFe', 'OAuth2 / OIDC', 'PixiJS', 'Grafana']
export function Marquee() {
  const items = [...marqueeItems, ...marqueeItems]
  return (
    <div className="marquee" aria-hidden="true">
      <motion.div
        className="marquee-track"
        animate={{ x: ['0%', '-50%'] }}
        transition={{ duration: 38, ease: 'linear', repeat: Infinity }}
      >
        {items.map((s, i) => <span key={s + i}>{s}</span>)}
      </motion.div>
    </div>
  )
}

function CopyRow({ k, v, href, copy }) {
  const [done, setDone] = useState(false)
  const onCopy = async () => {
    try { await navigator.clipboard.writeText(copy || v) ; setDone(true); setTimeout(() => setDone(false), 1500) }
    catch { const r = document.createRange(); r.selectNodeContents(document.getElementById('v-' + k)); const s = window.getSelection(); s.removeAllRanges(); s.addRange(r) }
  }
  return (
    <div className="crow">
      <div style={{ minWidth: 0 }}>
        <div className="k">{k}</div>
        <div className="v" id={'v-' + k}>{href ? <a href={href} target={href.startsWith('http') ? '_blank' : undefined} rel="noreferrer">{v}</a> : v}</div>
      </div>
      <button className="copy" onClick={onCopy} type="button">{done ? 'Copied' : 'Copy'}</button>
    </div>
  )
}

export function Contact() {
  return (
    <section className="section" id="contact">
      <div className="wrap contact">
        <motion.div variants={stagger} initial="hidden" whileInView="show" viewport={viewport}>
          <motion.span className="eyebrow" variants={fadeUp}>Contact</motion.span>
          <motion.h2 variants={fadeUp} style={{ marginTop: 14 }}>Hiring in Dubai? Let&rsquo;s talk.</motion.h2>
          <motion.p className="lede" variants={fadeUp}>
            Open to AI product owner, engineering manager and senior full-stack roles across the UAE. Based in Dubai, available immediately, happy to meet in Dubai or Abu Dhabi.
          </motion.p>
        </motion.div>
        <motion.div className="contact-card" initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={viewport} transition={{ duration: 0.6 }}>
          <CopyRow k="Email" v={profile.email} href={`mailto:${profile.email}`} />
          <CopyRow k="Phone" v={profile.phone} href={`tel:${profile.phone.replace(/\s/g, '')}`} />
          <CopyRow k="LinkedIn" v={profile.linkedinLabel} href={profile.linkedin} copy={profile.linkedin} />
          <CopyRow k="Location" v={profile.location} />
        </motion.div>
      </div>
    </section>
  )
}
