import { useEffect, useRef } from 'react'
import { motion, useInView, useMotionValue, useSpring } from 'framer-motion'
import { profile, stats, glance } from '../data'
import { fadeUp, stagger } from '../motion'

// Ambient "ops console" background: a slow drifting grid with a few signal pulses. Canvas, not SVG.
function Backdrop() {
  const ref = useRef(null)
  useEffect(() => {
    const canvas = ref.current
    const ctx = canvas.getContext('2d')
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    let raf, w, h, t = 0
    const pulses = Array.from({ length: 14 }, (_, i) => ({
      x: Math.random(), y: Math.random(), s: 0.4 + Math.random() * 0.8, p: Math.random() * Math.PI * 2, i,
    }))
    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2)
      w = canvas.clientWidth; h = canvas.clientHeight
      canvas.width = w * dpr; canvas.height = h * dpr
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }
    const accent = () => getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#f0a53a'
    const line = () => getComputedStyle(document.documentElement).getPropertyValue('--line').trim() || 'rgba(197,214,230,.12)'
    const draw = () => {
      ctx.clearRect(0, 0, w, h)
      const g = 48
      const off = (t * 6) % g
      ctx.strokeStyle = line()
      ctx.lineWidth = 1
      ctx.beginPath()
      for (let x = -g + off; x < w + g; x += g) { ctx.moveTo(x, 0); ctx.lineTo(x, h) }
      for (let y = -g + off; y < h + g; y += g) { ctx.moveTo(0, y); ctx.lineTo(w, y) }
      ctx.stroke()
      // vignette so the grid fades toward the text
      const grad = ctx.createRadialGradient(w * 0.25, h * 0.4, 40, w * 0.25, h * 0.4, Math.max(w, h) * 0.8)
      const bg = getComputedStyle(document.body).backgroundColor
      grad.addColorStop(0, bg)
      grad.addColorStop(1, 'rgba(0,0,0,0)')
      ctx.fillStyle = grad
      ctx.fillRect(0, 0, w, h)
      const ac = accent()
      pulses.forEach((p) => {
        const a = 0.25 + 0.25 * Math.sin(t * 1.2 * p.s + p.p)
        const x = ((p.x * w + t * 12 * p.s) % (w + 40)) - 20
        const y = p.y * h
        ctx.beginPath()
        ctx.fillStyle = ac
        ctx.globalAlpha = a
        ctx.arc(x, y, 2.2, 0, Math.PI * 2)
        ctx.fill()
        ctx.globalAlpha = a * 0.35
        ctx.beginPath()
        ctx.arc(x, y, 7, 0, Math.PI * 2)
        ctx.fill()
        ctx.globalAlpha = 1
      })
      if (!reduce) { t += 1 / 60; raf = requestAnimationFrame(draw) }
    }
    resize(); draw()
    window.addEventListener('resize', () => { resize(); if (reduce) draw() })
    return () => cancelAnimationFrame(raf)
  }, [])
  return <canvas ref={ref} className="hero-canvas" aria-hidden="true" />
}

function Counter({ value, suffix }) {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-10% 0px' })
  const mv = useMotionValue(0)
  const spring = useSpring(mv, { stiffness: 60, damping: 18 })
  useEffect(() => { if (inView) mv.set(value) }, [inView, value, mv])
  useEffect(() => spring.on('change', (v) => { if (ref.current) ref.current.textContent = Math.round(v) }), [spring])
  return (
    <b>
      <span ref={ref}>0</span>
      <small>{suffix}</small>
    </b>
  )
}

export default function Hero() {
  return (
    <header className="hero">
      <Backdrop />
      <div className="wrap">
        <motion.div className="hero-in" variants={stagger} initial="hidden" animate="show">
         <div className="hero-copy">
          <motion.div className="role-row" variants={fadeUp}>
            {profile.roles.map((r) => <span key={r}>{r}</span>)}
          </motion.div>
          <motion.h1 variants={fadeUp}>
            I don&rsquo;t prompt products into existence.<br />
            <em>I engineer them.</em>
          </motion.h1>
          <motion.p className="sub" variants={fadeUp}>{profile.sub}</motion.p>
          <motion.div className="hero-actions" variants={fadeUp}>
            <a className="btn primary" href={`mailto:${profile.email}`}>Email me</a>
            <a className="btn" href={profile.linkedin} target="_blank" rel="noreferrer">LinkedIn</a>
            <a className="btn" href={profile.cv} download>Download CV</a>
            <span className="avail"><i />{profile.availability}</span>
          </motion.div>
         </div>
          <motion.aside className="console" variants={fadeUp} aria-label="At a glance">
            <div className="console-bar"><span>salman.khan / status</span><span className="live"><i />open to offers</span></div>
            {glance.map((r) => (
              <div className="crow2" key={r.k}>
                <span className="k">{r.k}</span>
                <span className="v">
                  {r.v && <b>{r.v}</b>}
                  {r.sub && <div style={{ color: 'var(--muted)', fontSize: 13 }}>{r.sub}</div>}
                  {r.chips && <div className="chips">{r.chips.map((c) => <span className="chip" key={c}>{c}</span>)}</div>}
                </span>
              </div>
            ))}
          </motion.aside>
        </motion.div>

        <motion.ul
          className="stats"
          style={{ marginTop: 'clamp(40px, 6vw, 72px)' }}
          variants={stagger}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.3 }}
        >
          {stats.map((s) => (
            <motion.li className="stat" key={s.label} variants={fadeUp}>
              <Counter value={s.value} suffix={s.suffix} />
              <span>{s.label}</span>
            </motion.li>
          ))}
        </motion.ul>
      </div>
    </header>
  )
}
