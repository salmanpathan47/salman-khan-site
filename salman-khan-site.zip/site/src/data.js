// All content comes from Salman's CVs. Edit here, not in the components.

export const profile = {
  name: 'Salman Khan',
  roles: ['AI Technical Product Owner', 'Engineering Manager', 'Full-Stack Engineer'],
  tagline: 'I don’t prompt products into existence. I engineer them.',
  sub: 'Scalable, reliable, secure end-to-end systems — shipped where money and live operations are on the line.',
  location: 'Dubai, United Arab Emirates',
  phone: '+971 52 446 8580',
  email: 'salmanpathan47@gmail.com',
  linkedin: 'https://linkedin.com/in/salman-khan-031b6b5b',
  linkedinLabel: 'linkedin.com/in/salman-khan-031b6b5b',
  availability: 'Available immediately · UAE employment visa',
  cv: '/Salman_Khan_CV.pdf',
  since: 2013,
}

export const stats = [
  { value: 12, suffix: '+', label: 'years shipping production systems' },
  { value: 4, suffix: '', label: 'real-money games built from scratch to live' },
  { value: 55, suffix: '%', label: 'faster time-to-interactive after re-platforming (Boeing)' },
  { value: 40, suffix: '%', label: 'performance gain on live airport systems (FlyDubai)' },
  { value: 18, suffix: '%', label: 'conversion lift on e-commerce checkout (Lowe’s)' },
]

export const pillars = [
  {
    key: 'po',
    title: 'AI Technical Product Owner',
    lead: 'Backlog owner for AI-enabled operational platforms. Decides where AI helps and where deterministic logic must stay.',
    points: [
      'Shipped LLM features to production: RAG over operational knowledge, tool-calling agents, streaming AI dashboards.',
      'Epics, user stories, acceptance criteria and NFRs in Jira; PI planning and SAFe cadence across 5+ squads.',
      'Impact measured through adoption, processing time and efficiency KPIs — quarterly OKR reporting to leadership.',
      'Vendor and build-vs-buy decisions: payment gateways, document scanning, inference endpoints.',
    ],
  },
  {
    key: 'em',
    title: 'Engineering Manager',
    lead: 'Hands-on leader. Owns delivery, hiring, 1:1s and career growth while still reviewing every production change.',
    points: [
      'Led a 6-person team on FlyDubai’s check-in, boarding and departure-control platform.',
      'Coordinated 5+ agile squads (UI, API, DevOps) to recover an at-risk modernisation programme at Boeing.',
      'Runs engineering as an operating system: SLOs, incident response, defect SLAs, tech-debt register.',
      'Code-review culture, shared component libraries, Storybook testing and AI-assisted workflows adopted across teams.',
    ],
  },
  {
    key: 'fs',
    title: 'Full-Stack Engineer',
    lead: 'Writes the spec, builds across React / TypeScript and Node.js services on PostgreSQL, ships through CI/CD to Kubernetes.',
    points: [
      'Server-authoritative, idempotent, retry-safe transaction flows with wallet settlement and full audit trails.',
      'Tokenised, PCI-aware payment integration and OAuth2 / OIDC-secured APIs in live airport operations.',
      'React micro-frontends, Next.js SSR, PixiJS / WebGL game clients, Kafka / RabbitMQ eventing.',
      'Docker, Kubernetes, GitHub Actions, Azure DevOps on AWS and Azure; Grafana SLO monitoring.',
    ],
  },
]

export const principles = [
  {
    title: 'Engineered, not prompted',
    text: 'AI tooling speeds up research and delivery, but every production change is specified, reviewed and owned. Four externally certified game releases, with change control after certification.',
  },
  {
    title: 'Scalable by design',
    text: 'High-throughput, low-latency services for real-money gaming and airport operations. Event-driven architecture, caching middleware and capacity-aware planning.',
  },
  {
    title: 'Reliable in production',
    text: 'SLO-based monitoring and alerting, graceful degradation, blameless postmortems. Led a launch-critical airport incident to resolution with zero operational disruption.',
  },
  {
    title: 'Secure where it matters',
    text: 'OAuth2 / OIDC, role-based access, OWASP, secrets management, tokenised payments in a PCI-aware scope, wallet and settlement flows with audit trails.',
  },
  {
    title: 'End to end, not tickets',
    text: 'Discovery, user flows and acceptance criteria, SIT / UAT, go / no-go, cutover, go-live and hypercare. Accountable for the system after it ships.',
  },
  {
    title: 'Clear communicator',
    text: 'Comfortable from C-suite steering to code review. Runs demos for operator clients, aligns operations leads with IT and senior leadership, writes the status report people read.',
  },
]

export const aiWork = [
  {
    where: 'FlyDubai',
    title: 'RAG assistant for airport operations',
    text: 'Retrieval over operational rules and Confluence documentation so ground agents get answers immediately instead of raising tickets and waiting.',
    stack: ['OpenAI', 'LangChain.js', 'Node.js', 'Confluence'],
  },
  {
    where: 'FlyDubai',
    title: 'AI operational dashboards, streamed live',
    text: 'Real-time decision support inside the check-in system. Inference streamed from Node.js microservices into Next.js UIs over WebSockets / SSE; prompt flows orchestrated with Transformers.js and Hugging Face endpoints.',
    stack: ['Next.js', 'WebSockets / SSE', 'Transformers.js', 'Hugging Face'],
  },
  {
    where: 'Boeing',
    title: 'AI-driven data visualisation',
    text: 'Predictive analytics and insights in React dashboards with Node.js middleware for orchestration and caching to keep inference latency down. RAG over cargo documentation so teams self-serve answers.',
    stack: ['OpenAI SDK', 'LangChain.js', 'React', 'Databricks'],
  },
  {
    where: 'Darpha Studios',
    title: 'AI-assisted, spec-first engineering',
    text: 'Introduced Claude Code and Copilot into the team workflow with specs, review gates and ROI-ranked automation of content and releases.',
    stack: ['Claude Code', 'Copilot', 'Evals', 'Guardrails'],
  },
]

export const experience = [
  {
    company: 'Darpha Studios',
    role: 'Engineering Lead / Technical Product Owner',
    period: 'Nov 2025 – Present',
    place: 'Dubai, UAE',
    domain: 'Regulated real-money iGaming (B2B studio)',
    bullets: [
      'Shipped 4 slot games from scratch to live — PixiJS / WebGL clients through RTP / game-math certification — plus the operations backoffice, also built from scratch.',
      'Own the Node.js / TypeScript services and PostgreSQL data layer behind bet, spin and outcome flows against a Remote Gaming Server: server-authoritative, idempotent, retry-safe, with wallet settlement and full audit trails.',
      'Run the RICE-prioritised backlog, defect triage with severity SLAs and quarterly OKR / KPI reporting; demo games and backoffice to operator clients.',
    ],
  },
  {
    company: 'FlyDubai',
    role: 'Senior Lead Engineer / Technical Product Owner',
    period: 'May 2025 – Nov 2025',
    place: 'Dubai, UAE',
    domain: 'Check-in, boarding and departure-control platform',
    bullets: [
      'Led a 6-person team on mission-critical airport systems; improved application performance 40% and introduced feature governance and KPI reporting (~30% faster operational throughput).',
      'Built CI/CD on GitHub Actions and Azure DevOps with Docker / Kubernetes; tokenised payment integration and ScanDit document scanning.',
      'Shipped AI-powered operational dashboards and a RAG assistant for ground agents; led a launch-critical incident with zero operational disruption.',
    ],
  },
  {
    company: 'Boeing',
    role: 'Delivery Lead & Lead Engineer, Modernisation Programme',
    period: 'Apr 2023 – May 2025',
    place: 'Bengaluru, India',
    domain: 'Aviation legacy modernisation',
    bullets: [
      'Recovered an at-risk, partner-dependent programme, coordinating 5+ agile squads in a SAFe cadence.',
      'Re-platformed legacy VB6 systems to React micro-frontends over Node.js services and REST / GraphQL APIs — time-to-interactive down 55%; added Kafka / RabbitMQ eventing.',
      'Led the AIXM aviation-data migration and built the “golden thread” data-quality pipeline on Databricks.',
    ],
  },
  {
    company: 'Symphony AI',
    role: 'Senior UI Lead / Product Owner',
    period: 'Aug 2022 – Apr 2023',
    place: 'Bengaluru, India',
    domain: 'AI-powered operational analytics',
    bullets: [
      'Led an Angular team delivering AI decision-support products; set design-system and access-control standards and translated business problems into ROI-ranked roadmaps.',
    ],
  },
  {
    company: 'Lowe’s',
    role: 'Senior Engineer (UI / Node.js)',
    period: 'Oct 2020 – Aug 2022',
    place: 'Bengaluru, India',
    domain: 'E-commerce storefront',
    bullets: [
      'Moved the monolithic storefront (PLP, PDP, cart, checkout) to Next.js with SSR — bounce −25%, load time −60%, conversion +18%, validated through A/B testing.',
    ],
  },
  {
    company: 'Intel & Avaamo',
    role: 'Senior UI Developer',
    period: '2019 – 2020',
    place: 'Bengaluru, India',
    domain: 'Conversational AI for banking; chipset monitoring',
    bullets: [
      '100+ responsive screens, AngularJS-to-React migration, 80%+ faster key modules; React / Highcharts monitoring dashboard; SQL Server and Dynamics 365 / Dataverse integration.',
    ],
  },
  {
    company: 'Causeway Technologies',
    role: 'Senior UI Developer',
    period: 'Jul 2016 – Aug 2019',
    place: 'Bengaluru, India',
    domain: 'UK telematics product company',
    bullets: ['Built an e-commerce application end-to-end in React and Strapi with OAuth sign-in.'],
  },
  {
    company: 'NTT Data',
    role: 'Senior UI Developer',
    period: 'Oct 2013 – Jul 2016',
    place: 'Bengaluru, India',
    domain: 'Client web applications',
    bullets: ['Key website features in AngularJS and responsive layouts; improved page-load times.'],
  },
]

export const stack = [
  { group: 'Frontend', items: ['React', 'TypeScript', 'Next.js (SSR)', 'Redux', 'Micro-frontends', 'Design systems', 'Storybook', 'Angular', 'PixiJS / WebGL', 'Performance & a11y'] },
  { group: 'Backend & data', items: ['Node.js', 'NestJS / Express', 'Python', 'REST / OpenAPI', 'GraphQL', 'PostgreSQL', 'SQL Server', 'Kafka / RabbitMQ', 'WebSockets', 'Databricks'] },
  { group: 'AI / LLM', items: ['OpenAI API', 'LangChain.js', 'Transformers.js', 'Hugging Face', 'RAG & search', 'Tool-calling agents', 'Streaming inference', 'Evals & guardrails', 'Claude Code', 'Copilot'] },
  { group: 'Platform & security', items: ['Docker', 'Kubernetes', 'AWS', 'Azure', 'GitHub Actions', 'Azure DevOps', 'Grafana / SLOs', 'OAuth2 / OIDC', 'OWASP', 'PCI-aware payments'] },
  { group: 'Product & delivery', items: ['Agile / Scrum / SAFe', 'PI planning', 'RICE / WSJF', 'User stories & AC', 'UAT & go-live', 'Jira / Confluence', 'MS Project', 'Power BI', 'Figma', 'Dynamics 365 / Dataverse'] },
]

export const education = 'B.E. Computer Science — Oxford College of Engineering, Bengaluru (2009–2013)'
